# Musafir Nizam — GitHub Pages site

Static archive of **39 articles** from [musafirnizam.com](https://www.musafirnizam.com/), keeping **original publish dates**.

## Go live on GitHub

1. GitHub pe naya repo banao, e.g. `musafirnizam.github.io` (user site) **ya** `musafirnizam.com`.
2. Is folder ki **saari files** repo ke **root** mein upload / drag-drop karo (`index.html` upar ho, `css/`, `posts/`, `p/`).
3. Repo → **Settings → Pages**
   - Source: **Deploy from a branch**
   - Branch: `main` (root)
4. Custom domain (optional): Settings → Pages → Custom domain = `musafirnizam.com`
   - DNS pe CNAME: `www` → `YOURUSER.github.io`
   - Apex A records GitHub Pages IPs (GitHub docs)
5. 2–10 min baad site live.

`CNAME` file already has `musafirnizam.com`. Agar pehle test karna ho GitHub URL pe, is file ko hata sakte ho.

## Local preview

Open `index.html` in a browser, or run:

```
python3 -m http.server 8000
```

Articles: 39 · Pages: about, contact, terms, privacy, disclaimer
